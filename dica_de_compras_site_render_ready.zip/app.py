from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

# COLE SUA CHAVE AQUI
openai.api_key = "SUA_CHAVE_AQUI"

@app.route('/chat', methods=['POST'])
def chat():
    user_msg = request.json.get('message')
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": user_msg}]
        )
        reply = response.choices[0].message.content.strip()
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": f"Ocorreu um erro: {e}"}), 500

@app.route('/')
def index():
    return open("index.html", "r", encoding="utf-8").read()

if __name__ == '__main__':
    app.run(debug=True)